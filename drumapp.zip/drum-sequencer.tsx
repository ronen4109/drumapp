"use client"

import { useState, useMemo } from "react"
import { Play, Pause } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type TimeSignature = "4/4" | "3/4"
type Subdivision = "1/16" | "1/8" | "1/4"

const instruments = [
  { name: "Hi-hat", icon: "/icons/hihat.png", color: "cyan" },
  { name: "Kick", icon: "/icons/kick.png", color: "red" },
  { name: "Snare", icon: "/icons/snare.png", color: "orange" },
  { name: "Tom 1", icon: "/icons/tom1.png", color: "purple" },
  { name: "Tom 2", icon: "/icons/tom2.png", color: "pink" },
  { name: "Floor Tom", icon: "/icons/floortom.png", color: "yellow" },
  { name: "Crash", icon: "/icons/crash.png", color: "green" },
  { name: "Ride", icon: "/icons/ride.png", color: "teal" },
]

const colorClasses = {
  cyan: {
    active: "bg-cyan-500 border-cyan-400 shadow-lg shadow-cyan-500/50",
    hover: "hover:border-cyan-500",
  },
  red: {
    active: "bg-red-500 border-red-400 shadow-lg shadow-red-500/50",
    hover: "hover:border-red-500",
  },
  orange: {
    active: "bg-orange-500 border-orange-400 shadow-lg shadow-orange-500/50",
    hover: "hover:border-orange-500",
  },
  purple: {
    active: "bg-purple-500 border-purple-400 shadow-lg shadow-purple-500/50",
    hover: "hover:border-purple-500",
  },
  pink: {
    active: "bg-pink-500 border-pink-400 shadow-lg shadow-pink-500/50",
    hover: "hover:border-pink-500",
  },
  yellow: {
    active: "bg-yellow-500 border-yellow-400 shadow-lg shadow-yellow-500/50",
    hover: "hover:border-yellow-500",
  },
  green: {
    active: "bg-green-500 border-green-400 shadow-lg shadow-green-500/50",
    hover: "hover:border-green-500",
  },
  teal: {
    active: "bg-teal-500 border-teal-400 shadow-lg shadow-teal-500/50",
    hover: "hover:border-teal-500",
  },
}

export default function DrumSequencer() {
  const [timeSignature, setTimeSignature] = useState<TimeSignature>("4/4")
  const [subdivision, setSubdivision] = useState<Subdivision>("1/16")
  const [tempo, setTempo] = useState(120)
  const [isPlaying, setIsPlaying] = useState(false)

  // Calculate grid dimensions
  const { columns, beatHeaders } = useMemo(() => {
    const beats = timeSignature === "4/4" ? 4 : 3
    const subdivisions = subdivision === "1/16" ? 4 : subdivision === "1/8" ? 2 : 1
    const totalColumns = beats * subdivisions

    // Create headers array with correct beat positioning
    const headers = new Array(totalColumns).fill("")

    // Place beat numbers at the correct positions
    for (let beat = 1; beat <= beats; beat++) {
      const position = (beat - 1) * subdivisions
      headers[position] = beat.toString()
    }

    return { columns: totalColumns, beatHeaders: headers }
  }, [timeSignature, subdivision])

  // Initialize sequencer state
  const [sequencerState, setSequencerState] = useState<boolean[][]>(() =>
    instruments.map(() => new Array(16).fill(false)),
  )

  // Update sequencer state when grid size changes
  const adjustedSequencerState = useMemo(() => {
    return sequencerState.map((row) => {
      const newRow = [...row]
      if (newRow.length < columns) {
        // Extend with false values
        return [...newRow, ...new Array(columns - newRow.length).fill(false)]
      } else if (newRow.length > columns) {
        // Truncate
        return newRow.slice(0, columns)
      }
      return newRow
    })
  }, [sequencerState, columns])

  const toggleCell = (instrumentIndex: number, stepIndex: number) => {
    setSequencerState((prev) => {
      const newState = [...prev]
      newState[instrumentIndex] = [...newState[instrumentIndex]]
      newState[instrumentIndex][stepIndex] = !newState[instrumentIndex][stepIndex]
      return newState
    })
  }

  const handlePlay = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Control Panel */}
        <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
          <h1 className="text-2xl font-bold mb-6 text-center">Drum Machine Sequencer</h1>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            {/* Time Signature */}
            <div className="space-y-2">
              <Label htmlFor="time-signature" className="text-sm font-medium text-gray-300">
                Time Signature
              </Label>
              <Select value={timeSignature} onValueChange={(value: TimeSignature) => setTimeSignature(value)}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="4/4" className="text-white hover:bg-gray-600">
                    4/4
                  </SelectItem>
                  <SelectItem value="3/4" className="text-white hover:bg-gray-600">
                    3/4
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Subdivision */}
            <div className="space-y-2">
              <Label htmlFor="subdivision" className="text-sm font-medium text-gray-300">
                Subdivision
              </Label>
              <Select value={subdivision} onValueChange={(value: Subdivision) => setSubdivision(value)}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="1/16" className="text-white hover:bg-gray-600">
                    1/16
                  </SelectItem>
                  <SelectItem value="1/8" className="text-white hover:bg-gray-600">
                    1/8
                  </SelectItem>
                  <SelectItem value="1/4" className="text-white hover:bg-gray-600">
                    1/4
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Tempo */}
            <div className="space-y-2">
              <Label htmlFor="tempo" className="text-sm font-medium text-gray-300">
                Tempo (BPM)
              </Label>
              <Input
                id="tempo"
                type="number"
                value={tempo}
                onChange={(e) => setTempo(Number(e.target.value))}
                min={60}
                max={200}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            {/* Play Button */}
            <Button
              onClick={handlePlay}
              size="lg"
              className={`h-12 ${
                isPlaying ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"
              } text-white font-semibold`}
            >
              {isPlaying ? (
                <>
                  <Pause className="w-5 h-5 mr-2" />
                  Stop
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  Play
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Sequencer Grid */}
        <div className="bg-gray-800 rounded-lg p-6 shadow-lg overflow-x-auto">
          <div className="min-w-fit">
            {/* Beat Headers */}
            <div
              className="grid gap-1 mb-4"
              style={{
                gridTemplateColumns: `140px repeat(${columns}, 40px)`,
              }}
            >
              <div></div>
              {beatHeaders.map((header, index) => (
                <div
                  key={index}
                  className="text-center text-sm font-bold text-gray-300 py-2 flex items-center justify-center"
                >
                  {header}
                </div>
              ))}
            </div>

            {/* Sequencer Rows */}
            <div className="space-y-2">
              {instruments.map((instrument, instrumentIndex) => {
                const colors = colorClasses[instrument.color as keyof typeof colorClasses]

                return (
                  <div
                    key={instrument.name}
                    className="grid gap-1 items-center"
                    style={{
                      gridTemplateColumns: `140px repeat(${columns}, 40px)`,
                    }}
                  >
                    {/* Instrument Label with Icon */}
                    <div className="flex items-center justify-end gap-3 pr-4">
                      <span className="text-sm font-medium text-gray-300">{instrument.name}</span>
                      <img
                        src={instrument.icon || "/placeholder.svg"}
                        alt={instrument.name}
                        className="w-5 h-5 object-contain"
                        onError={(e) => {
                          // Fallback to placeholder if image fails to load
                          e.currentTarget.src = `/placeholder.svg?height=20&width=20&text=${instrument.name.charAt(0)}`
                        }}
                      />
                    </div>

                    {/* Step Buttons */}
                    {adjustedSequencerState[instrumentIndex].slice(0, columns).map((isActive, stepIndex) => (
                      <button
                        key={stepIndex}
                        onClick={() => toggleCell(instrumentIndex, stepIndex)}
                        className={`
                          w-10 h-10 rounded border-2 transition-all duration-150 hover:scale-110
                          ${
                            isActive
                              ? colors.active
                              : `bg-gray-700 border-gray-600 hover:border-gray-500 ${colors.hover}`
                          }
                        `}
                        aria-label={`${instrument.name} step ${stepIndex + 1}`}
                      />
                    ))}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Info Panel */}
        <div className="bg-gray-800 rounded-lg p-4 text-center">
          <p className="text-gray-400 text-sm">
            Grid: {columns} steps ({timeSignature} time, {subdivision} subdivision) • Tempo: {tempo} BPM
          </p>
        </div>
      </div>
    </div>
  )
}
